package GameObjects;

public abstract class PlayerObject {
    abstract public void getHit(float damage);
    abstract public float getTargetX();
    abstract public float getTargetY();
}
